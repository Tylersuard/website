from django.contrib import admin
from .models import *



class APIAdmin(admin.ModelAdmin):
    list_display = ('user', 'key', 'created_at', 'payment')

class CONTACTAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'message', 'created_at')

admin.site.register(API, APIAdmin)
admin.site.register(CONTACT, CONTACTAdmin)