from datetime import timedelta, date
from django.core.mail import EmailMessage
from django.conf import settings
from .models import API
from django.utils import timezone


def sendMail(email, subject, body):
	email_subject = subject
	email_body = body
	email = EmailMessage(subject=email_subject, body=email_body, from_email=settings.EMAIL_FROM_USER, 
	to=[email])
	email.send()



def apialertcron():
    subject = "Api Deactivation Alert!"
    oldtoday = timezone.now() - timedelta(days=25)
    # oldtoday = datetime.now() - timedelta(days=25)
    apis = API.objects.filter(created_at__lte=oldtoday)
    for api in apis:

        olddate = api.created_at
        newdate = date.today()
        date1 = date(olddate.year, olddate.month, olddate.day)
        date2 = date(newdate.year, newdate.month, newdate.day)
        days_left = api.payment.sub_exp - (date2-date1).days
        if days_left > 1:
            body = f"Your Api Has Been Deactivated In Next {days_left} Days Please Upgrade Your Subscription To Prevent From Deactivating Your Api Key, Thank You!"
            sendMail(api.user.username, subject, body)
        print('\nCron Job Done.\n')
    print('\nCron Job Is Running.\n')









def apideletetcron():
    subject = "Api Deactivation Alert!"
    body = "Your Api Has Been Deactivated Please Login To Our Website And Subscribe Again To Use Our Api Key Features, Thank You!"
    oldtoday = timezone.now() - timedelta(days=30)
    # oldtoday = datetime.now() - timedelta(days=30)
    apis = API.objects.filter(created_at__lte=oldtoday)
    for api in apis:
        ap = API.objects.filter(id=api.id).last()
        ap.payment.status = "done"
        ap.payment.save()
        ap.save()
        ap.delete()
        sendMail(api.user.username, subject, body)
        print('\nCron Job Done.\n')
    print('\nCron Job Is Running.\n')